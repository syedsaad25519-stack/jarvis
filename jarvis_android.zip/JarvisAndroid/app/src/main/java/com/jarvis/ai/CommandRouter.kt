package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.net.Uri

class CommandRouter(private val context: Context, private val respond: (String) -> Unit) {

    private val aiBrain = AiBrain(context)
    private val appLauncher = AppLauncher(context)
    private val reminderManager = ReminderManager(context)
    private val termuxBridge = TermuxBridge(context)
    private val screenAgent = ScreenAgent(context)

    fun handle(rawText: String) {
        val text = rawText.lowercase().replace("jarvis", "").trim()
        if (text.isEmpty()) return

        when {
            text.contains("termux") -> {
                val command = text.substringAfter("termux").trim()
                respond(termuxBridge.runCommand(command))
            }
            text.contains("open") -> {
                val target = text.replace(Regex("\\bopen\\b"), "").trim()
                respond(appLauncher.openApp(target))
            }
            text.contains("remind me") -> respond(reminderManager.setReminder(text))
            text.startsWith("search") || text.contains("search for") -> {
                val query = (if (text.contains("for")) text.substringAfter("for") else text.substringAfter("search")).trim()
                openWebSearch(query)
                respond("Searching for $query")
            }
            (text.contains("complete") || text.contains("finish")) && text.contains("level") -> {
                respond(screenAgent.start(text))
            }
            else -> aiBrain.ask(text, respond)
        }
    }

    private fun openWebSearch(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
