package com.jarvis.ai

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar
import java.util.regex.Pattern

class ReminderManager(private val context: Context) {

    private val inPattern = Pattern.compile("remind me to (.+?) in (\\d+)\\s*(minute|minutes|hour|hours)")
    private val atPattern = Pattern.compile("remind me to (.+?) at (\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?")

    fun setReminder(text: String): String {
        val cal = Calendar.getInstance()
        val task: String

        val inMatcher = inPattern.matcher(text)
        val atMatcher = atPattern.matcher(text)

        when {
            inMatcher.find() -> {
                task = inMatcher.group(1) ?: return fallback()
                val amount = inMatcher.group(2)!!.toInt()
                val unit = inMatcher.group(3)!!
                if (unit.startsWith("hour")) cal.add(Calendar.HOUR_OF_DAY, amount)
                else cal.add(Calendar.MINUTE, amount)
            }
            atMatcher.find() -> {
                task = atMatcher.group(1) ?: return fallback()
                var hour = atMatcher.group(2)!!.toInt()
                val minute = atMatcher.group(3)?.toInt() ?: 0
                val meridiem = atMatcher.group(4)
                if (meridiem == "pm" && hour != 12) hour += 12
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                cal.set(Calendar.SECOND, 0)
                if (cal.timeInMillis < System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            else -> return fallback()
        }

        val intent = Intent(context, ReminderReceiver::class.java).putExtra("task", task.trim())
        val requestCode = System.currentTimeMillis().toInt()
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)

        return "Got it, I'll remind you to ${task.trim()}"
    }

    private fun fallback() = "Tell me what to remind you and when, like 'remind me to call mom in 20 minutes'"
}
