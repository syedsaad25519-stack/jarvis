package com.jarvis.ai

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * Attempts a goal on-screen by repeatedly screenshotting, asking Claude what to
 * tap/swipe next, and performing that action. This is a genuine best-effort
 * agent loop (the same pattern behind "computer use" agents) — not a guaranteed
 * win for any specific game or app, since it has no game-specific training.
 */
class ScreenAgent(private val context: Context) {

    private val client = OkHttpClient()
    private var stepsRemaining = 0
    private var goal = ""

    fun start(goal: String, maxSteps: Int = 8): String {
        val service = JarvisAccessibilityService.instance
            ?: return "Turn on the Screen Agent in Settings > Accessibility first."
        val apiKey = Prefs.getApiKey(context)
        if (apiKey.isNullOrBlank()) return "I need an Anthropic API key set in Settings first."

        this.goal = goal
        this.stepsRemaining = maxSteps
        step(service, apiKey)
        return "Working on it: $goal"
    }

    private fun step(service: JarvisAccessibilityService, apiKey: String) {
        if (stepsRemaining <= 0) return
        stepsRemaining--

        service.takeScreenshotForAgent { bitmap ->
            if (bitmap == null) return@takeScreenshotForAgent
            askForNextAction(bitmapToBase64(bitmap), apiKey) { action ->
                performAction(service, action)
                if (action.optString("action") != "done" && stepsRemaining > 0) {
                    Handler(Looper.getMainLooper()).postDelayed({ step(service, apiKey) }, 1200)
                }
            }
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private fun askForNextAction(base64Image: String, apiKey: String, callback: (JSONObject) -> Unit) {
        val prompt = """
            You control an Android screen to achieve this goal: "$goal".
            Look at the screenshot and reply ONLY with JSON, no other text:
            {"action":"tap","x":123,"y":456,"reason":"..."} or
            {"action":"swipe","x1":100,"y1":800,"x2":100,"y2":300,"reason":"..."} or
            {"action":"done","reason":"..."} if the goal looks complete or you can't safely proceed.
        """.trimIndent()

        val body = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 300)
            put("messages", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", JSONArray().apply {
                    put(JSONObject().apply {
                        put("type", "image")
                        put("source", JSONObject().apply {
                            put("type", "base64")
                            put("media_type", "image/png")
                            put("data", base64Image)
                        })
                    })
                    put(JSONObject().apply {
                        put("type", "text")
                        put("text", prompt)
                    })
                })
            }))
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(JSONObject().put("action", "done").put("reason", "network error"))
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val raw = response.body?.string() ?: "{}"
                    val text = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
                    val cleaned = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                    callback(JSONObject(cleaned))
                } catch (e: Exception) {
                    callback(JSONObject().put("action", "done").put("reason", "parse error"))
                }
            }
        })
    }

    private fun performAction(service: JarvisAccessibilityService, action: JSONObject) {
        when (action.optString("action")) {
            "tap" -> service.tap(action.optDouble("x").toFloat(), action.optDouble("y").toFloat())
            "swipe" -> service.swipe(
                action.optDouble("x1").toFloat(), action.optDouble("y1").toFloat(),
                action.optDouble("x2").toFloat(), action.optDouble("y2").toFloat()
            )
        }
    }
}
