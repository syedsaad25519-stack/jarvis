package com.jarvis.ai

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

class AppLauncher(private val context: Context) {

    fun openApp(spokenName: String): String {
        val pm = context.packageManager
        val target = spokenName.trim().lowercase()
        if (target.isEmpty()) return "What should I open?"

        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }

        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(target)
        }

        if (match == null) return "I couldn't find an app called $target on this phone"

        val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return "I found $target but it has no launcher screen"

        context.startActivity(launchIntent)
        return "Opening ${pm.getApplicationLabel(match)}"
    }
}
