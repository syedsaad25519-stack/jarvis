package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Locale
import java.util.Timer
import java.util.TimerTask

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private lateinit var statusText: TextView
    private lateinit var voiceManager: VoiceManager
    private lateinit var commandRouter: CommandRouter
    private lateinit var tts: TextToSpeech
    private var mouthTimer: Timer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.faceWebView)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/robot_face.html")

        statusText = findViewById(R.id.statusText)
        tts = TextToSpeech(this, this)

        commandRouter = CommandRouter(this) { response -> speak(response) }
        voiceManager = VoiceManager(this) { heard -> onHeard(heard) }

        findViewById<FloatingActionButton>(R.id.micButton).setOnClickListener {
            ensureMicPermission { startListening() }
        }

        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        ensureMicPermission { }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    private fun ensureMicPermission(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    private fun startListening() {
        statusText.text = "Listening..."
        webView.evaluateJavascript("setListening(true)", null)
        voiceManager.startListening()
    }

    private fun onHeard(text: String) {
        webView.evaluateJavascript("setListening(false)", null)
        if (text.isBlank()) {
            statusText.text = "Didn't catch that — tap the mic to try again"
            return
        }
        statusText.text = "You: $text"
        commandRouter.handle(text)
    }

    private fun speak(response: String) {
        statusText.text = response
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = animateMouth(true)
            override fun onDone(utteranceId: String?) = animateMouth(false)
            override fun onError(utteranceId: String?) = animateMouth(false)
        })
        tts.speak(response, TextToSpeech.QUEUE_FLUSH, Bundle(), "jarvis_utterance")
    }

    private fun animateMouth(speaking: Boolean) {
        mouthTimer?.cancel()
        if (!speaking) {
            runOnUiThread { webView.evaluateJavascript("setMouthOpen(0)", null) }
            return
        }
        mouthTimer = Timer()
        mouthTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                val value = Math.random()
                runOnUiThread { webView.evaluateJavascript("setMouthOpen($value)", null) }
            }
        }, 0, 120)
    }

    override fun onDestroy() {
        tts.shutdown()
        voiceManager.destroy()
        mouthTimer?.cancel()
        super.onDestroy()
    }
}
