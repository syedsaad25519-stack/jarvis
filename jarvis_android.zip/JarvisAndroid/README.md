# Jarvis — Android voice assistant with 3D robot face

A real Android app: 3D animated robot head, voice conversation powered by Claude,
app launching, reminders, web search, Termux command execution, and a
vision-guided "screen agent" that can attempt on-screen goals.

## What this honestly is (read this first)

- This is **source code for an Android Studio project**, not a ready-made .apk.
  You build the .apk yourself in Android Studio (free, official tool) — that's
  the normal way any real Android app gets made, whether by a solo developer or
  a big company.
- The **3D face** is a stylized robot head (glowing eyes, moving mouth), built
  with Three.js — not a photorealistic human. It's easy to swap for a fancier
  3D model later if you want.
- **Wake-word / always-listening** isn't included — Android restricts
  background microphone use heavily, so this uses **tap-to-talk** (press the
  mic button, then speak). This is more reliable in practice on a phone anyway.
- The **"complete this level" screen agent** is a genuine best-effort loop —
  screenshot, ask Claude what to tap, tap it, repeat — the same pattern behind
  "computer use" AI agents. It is not a guaranteed win for any specific game;
  no one can promise that, since it has no training on your specific game.
- **Opening any app by name** works because this is a personal, sideloaded app
  (not published on the Play Store) — Play Store review would restrict the
  broad app-visibility permission used here.

## 1. Install Android Studio

Download from https://developer.android.com/studio and run the installer.
Accept the default setup — this installs the Android SDK too.

## 2. Open the project

Unzip the project, then in Android Studio: **File > Open** and select the
`JarvisAndroid` folder. Let Gradle sync (needs internet — it downloads
dependencies the first time).

## 3. Connect your phone or use an emulator

- **Real phone (recommended)**: enable Developer Options (Settings > About
  phone > tap "Build number" 7 times), then enable USB debugging (Settings >
  Developer options). Plug in via USB, allow the debugging prompt.
- **Emulator**: Tools > Device Manager > create a virtual device.

## 4. Build the APK

**Build > Build App Bundle(s) / APK(s) > Build APK(s)**. When it finishes,
click "locate" in the notification to find `app-debug.apk`, or just click the
green ▶ Run button to install and launch it directly on your connected phone.

## 5. First run — grant permissions

- Allow microphone access when prompted.
- Allow notifications when prompted (for reminders).
- Open the **settings icon** (top right) in the app:
  - Paste your **Anthropic API key** (get one at
    https://console.anthropic.com/settings/keys) and tap Save — needed for
    conversation, web search follow-ups, and the screen agent.
  - Tap **"Enable Screen Agent"** → this opens Android's Accessibility
    settings → find "Jarvis" in the list → turn it on. (Only needed for the
    "complete this level" style commands.)
  - Tap **"Grant Termux Command Permission"** if you'll use Termux commands.

## 6. Set up Termux (only if you want the Termux command feature)

1. Install Termux from F-Droid (not the outdated Play Store version):
   https://f-droid.org/packages/com.termux/
2. Open Termux once, then run:
   ```
   mkdir -p ~/.termux
   echo "allow-external-apps=true" >> ~/.termux/termux.properties
   termux-reload-settings
   ```
3. Restart Termux.
4. In Jarvis, tap "Grant Termux Command Permission" in Settings and accept
   the permission dialog.

## 7. Talking to it

Tap the mic button, then say things like:

- "open YouTube" / "open Spotify" — launches installed apps
- "remind me to check the oven in 10 minutes" / "remind me to call mom at 6pm"
- "search for the weather tomorrow" — opens a Google search
- "what is the speed of light" — answered via Claude
- "run ls in termux" — executes a shell command in Termux
- "complete this level" (with the game open behind Jarvis, and Screen Agent
  enabled) — attempts a vision-guided sequence of taps toward that goal

## 8. Customizing

- `CommandRouter.kt` — add new voice command patterns here.
- `robot_face.html` — tweak the 3D face (colors, shape, add a real GLTF model
  for a more detailed humanoid look).
- `ScreenAgent.kt` — adjust `maxSteps`, the prompt, or swap in a different
  vision model.

## Troubleshooting

If Gradle sync fails, it's almost always a missing SDK component — Android
Studio will show a clickable "Install missing SDK" link, click it. If the
screen agent doesn't respond, double check Accessibility is enabled for
Jarvis specifically (Android sometimes disables it after app updates —
you'll need to re-enable it each time you reinstall the APK).
