package com.jarvis.ai

import android.content.Context
import android.content.Intent

class TermuxBridge(private val context: Context) {

    /** Requires: Termux installed, allow-external-apps=true in ~/.termux/termux.properties,
     *  and the com.termux.permission.RUN_COMMAND permission granted to this app. */
    fun runCommand(command: String): String {
        if (command.isBlank()) return "What command should I run in Termux?"
        return try {
            val intent = Intent().apply {
                setClassName("com.termux", "com.termux.app.RunCommandService")
                action = "com.termux.RUN_COMMAND"
                putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", command))
                putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
            }
            context.startForegroundService(intent)
            "Running in Termux: $command"
        } catch (e: Exception) {
            "I couldn't reach Termux — check it's installed and command permission is granted. (${e.message})"
        }
    }
}
