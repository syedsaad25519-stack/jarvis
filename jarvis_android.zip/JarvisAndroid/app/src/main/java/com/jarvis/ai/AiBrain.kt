package com.jarvis.ai

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class AiBrain(private val context: Context) {

    private val client = OkHttpClient()

    fun ask(question: String, callback: (String) -> Unit) {
        val apiKey = Prefs.getApiKey(context)
        if (apiKey.isNullOrBlank()) {
            callback("I need an Anthropic API key set in Settings first.")
            return
        }

        val body = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 500)
            put("messages", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", question)
            }))
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("I couldn't reach the AI service: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string() ?: "{}"
                try {
                    val json = JSONObject(raw)
                    val text = json.getJSONArray("content").getJSONObject(0).getString("text")
                    callback(text)
                } catch (e: Exception) {
                    callback("Sorry, I couldn't parse that response.")
                }
            }
        })
    }
}
